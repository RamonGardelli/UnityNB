## intent:temas
- [uniones quimicas](tema)
- [estructura atomica](tema)
- [tabla periodica](tema)

## intent:explicarTema
- me explicarias [uniones quimicas](tema)
- me podes explicar [estructura atomica](tema)
- podrias explicar [tabla periodica](tema)
- no entiendo

## intent:darEjemplo
- me darias un ejemplo [uniones quimicas](tema)
- un ejemplo cual seria [estructura atomica](tema)
- un ejemplo [tabla periodica](tema)
- me decis un ejemplo

## intent:examenes
- [parcial](examen)
- [recuperatorio](examen)
- [prefinal](examen)

## intent:preguntarFechas
- cuales son las fechas de los examenes
- cuando se rinde el [parcial](examen)
- cual es la fecha del [recuperatorio](examen)
- cual es la fecha del [prefinal](examen)
- cuando son las instancias de examenes

## intent:noSeEntiende
- no entiendo
- no se entiende
- no estaria entendiendo
- lo podrias explicar otra vez

## intent:agradecer
- gracias
- muchas gracias
- buenisimo, gracias
- te agradezco

## intent:saludar
- hola
- buenos dias
- buenas tardes
- buenas noches
- buenas

